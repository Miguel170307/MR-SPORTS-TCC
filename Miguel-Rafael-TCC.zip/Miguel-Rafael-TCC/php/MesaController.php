<?php
class MesaController {
    private $db;
    private $requestMethod;
    private $mesaId;

    private $mesa;

    public function __construct($db, $requestMethod, $mesaId) {
        $this->db = $db;
        $this->requestMethod = $requestMethod;
        $this->mesaId = $mesaId;

        $this->mesa = new Mesa($db);
    }

    public function processRequest() {
        switch ($this->requestMethod) {
            case 'GET':
                if ($this->mesaId) {
                    $this->verificarMesa($this->mesaId);
                } else {
                    $this->getAllMesas();
                }
                break;
            default:
                $this->notFoundResponse();
                break;
        }
    }

    private function getAllMesas() {
        $stmt = $this->mesa->read();
        $mesas_arr = array();
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $mesa_item = array(
                "id" => $id
            );
            array_push($mesas_arr, $mesa_item);
        }
        
        http_response_code(200);
        echo json_encode($mesas_arr);
    }

    private function verificarMesa($id) {
        $this->mesa->id = $id;
        $exists = $this->mesa->exists();
        
        if($exists) {
            http_response_code(200);
            echo json_encode(array("message" => "Mesa existe"));
        } else {
            http_response_code(404);
            echo json_encode(array("message" => "Mesa não existe"));
        }
    }

    private function notFoundResponse() {
        http_response_code(404);
        echo json_encode(array("message" => "Rota não encontrada"));
    }
}
?>