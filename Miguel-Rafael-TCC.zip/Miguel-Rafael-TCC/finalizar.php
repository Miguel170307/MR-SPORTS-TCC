<?php
session_start();
include 'conexao.php';

// Verifica se há itens no carrinho
if (!isset($_SESSION['carrinho']) || empty($_SESSION['carrinho'])) {
    header('Location: carrinho.html');
    exit;
}

// Processa o formulário de pagamento
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $forma_pagamento = $_POST['pagamento'];
    $total = 0;
    
    // Calcula o total
    foreach ($_SESSION['carrinho'] as $item) {
        $total += $item['preco'] * $item['quantidade'];
    }
    
    // Insere o pedido no banco de dados (simplificado)
    $sql = "INSERT INTO pedidos (total, forma_pagamento, status) VALUES (?, ?, 'preparando')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ds", $total, $forma_pagamento);
    $stmt->execute();
    
    // Limpa o carrinho
    unset($_SESSION['carrinho']);
    
    // Redireciona para página de confirmação
    header('Location: obrigado.html');
    exit;
}

// Se não for POST, mostra o formulário
?>
<!DOCTYPE html>
<html>
<head>
    <title>Finalizar Pedido</title>
    <!-- Seus estilos -->
</head>
<body>
    <!-- Sua navbar -->
    
    <div class="container">
        <h2>Finalizar Pedido</h2>
        <form method="POST">
            <div class="form-group">
                <label>Forma de Pagamento:</label>
                <select name="pagamento" class="form-control">
                    <option value="pix">PIX</option>
                    <option value="cartao">Cartão de Crédito/Débito</option>
                </select>
            </div>
            <button type="submit" class="btn btn-success">Confirmar Pedido</button>
        </form>
    </div>
</body>
</html>